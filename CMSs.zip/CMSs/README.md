## A Blog Admin Dashboard

**Features:** 
* Simulated real-time connection to a site's backend (REST API)
* Use of browser's local storage to persist data

[Live Demo](https://blog-admin-ui.netlify.app/)
![Preview Image](https://i.imgur.com/uDRIyky.png)
